﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Plane> _list;
        public MainWindow()
        {
            InitializeComponent();

            Random randomGenerator = new Random();

            List<Flight> flights_1 = new List<Flight>()
            {
                new Flight() { Origin="WAW", Destination="BCN", Number="FR-4758", Duration = TimeSpan.FromMinutes(147), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="WAW", Destination="BER", Number="FR-7872", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
            };

            List<Flight> flights_2 = new List<Flight>()
            {
                new Flight() { Origin="BCN", Destination="MAD", Number="FR-4779", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="MAD", Destination="LHR", Number="LH-1835", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="FCO", Destination="CDG", Number="W-63901", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
            };

            List<Flight> flights_3 = new List<Flight>()
            {
                new Flight() { Origin="CGN", Destination="VIE", Number="LO-385", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="KRK", Destination="NAP", Number="KL-921", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="MUC", Destination="BER", Number="EK-39", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="LHR", Destination="EDI", Number="W-63901", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
            };

            List<Flight> flights_4 = new List<Flight>()
            {
                new Flight() { Origin="CGN", Destination="VIE", Number="LO-375", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="LHR", Destination="EDI", Number="W-68971", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
            };

            List<Flight> flights_5 = new List<Flight>()
            {
                new Flight() { Origin="KRK", Destination="VIE", Number="EK-78", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
                new Flight() { Origin="WAW", Destination="EDI", Number="KL-993", Duration = TimeSpan.FromMinutes(randomGenerator.Next(18, 265)), DepartureTime = DateTime.FromFileTime(randomGenerator.Next()) },
            };

            /* */
            _list = new List<Plane>()
            {
                new Plane() { Brand = "Boeing 737", Registration = "OHR-428", Capacity = randomGenerator.Next(130, 340), Weight=randomGenerator.Next(130, 340), Flights = flights_1 },
                new Plane() { Brand = "Boeing 777", Registration = "GTO-179", Capacity = randomGenerator.Next(130, 340), Weight=randomGenerator.Next(130, 340), Flights = flights_2 },
                new Plane() { Brand = "Airbus A319", Registration = "SP-FXM", Capacity = randomGenerator.Next(130, 340), Weight=randomGenerator.Next(130, 340), Flights = flights_3 },
                new Plane() { Brand = "Airbus A380", Registration = "D-TRYZ", Capacity = randomGenerator.Next(130, 340), Weight=randomGenerator.Next(130, 340), Flights = flights_4 },
                new Plane() { Brand = "Cesna 172", Registration = "G-KATM", Capacity = randomGenerator.Next(1, 2), Weight=randomGenerator.Next(8, 18), Flights = flights_5 },
                new Plane() { Brand = "Cessna Citation", Registration = "EC-TER", Capacity = randomGenerator.Next(2, 8), Weight=randomGenerator.Next(15, 35), Flights = flights_1 },
            };
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = _list;
        }

        //private void OnSelected1(object sender, MouseButtonEventArgs e)
        //{
        //    var dataContext = ((FrameworkElement)e.OriginalSource).DataContext;
        //    if(dataContext is Plane)
        //    {
        //        Plane p = (Plane)dataContext;
        //        modelName.Text = p.Brand;
        //        registrationNumber.Text = p.Registration;
        //        capacity.Text = p.Capacity.ToString();
        //        mass.Text = (p.Weight * 1000).ToString();

        //    }
        //}

        //private void ListViewItem2_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        //{
        //    var dataContext = ((FrameworkElement)e.OriginalSource).DataContext;
        //    if (dataContext is Flight)
        //    {
        //        Flight f = (Flight)dataContext;
        //    }
        //}

        //private void OnSelect1(object sender, RoutedEventArgs e)
        //{
        //    var dataContext = ((FrameworkElement)e.OriginalSource).DataContext;
        //    if (dataContext is Plane)
        //    {
        //        Plane p = (Plane)dataContext;
        //        modelName.Text = p.Brand;
        //        registrationNumber.Text = p.Registration;
        //        capacity.Text = p.Capacity.ToString();
        //        mass.Text = (p.Weight * 1000).ToString();

        //    }
        //}
    }

    public class converter1 : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value is int)
            {
                int x = (int)value * 1000;
                return x.ToString();
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class converter2 : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Flight)
            {
                Flight f = (Flight)value;
                return f.DepartureTime + f.Duration;
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
