﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;

namespace WPF22_16
{
    /// <summary>
    /// Interaction logic for Page2.xaml
    /// </summary>
    public partial class Page2 : Page
    {
        public ObservableCollection<Item> collection;
        public Page2()
        {
            InitializeComponent();

            collection = new ObservableCollection<Item>();
            this.DataContext = collection;

        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("PagePassword.xaml", UriKind.Relative));
        }

        private void ContextAddDirectory_Click(object sender, RoutedEventArgs e)
        {
            if (sender is DirectoryItem)
            {
                ((DirectoryItem)e.OriginalSource).items.Add(new DirectoryItem((DirectoryItem)e.OriginalSource));
            }
            else
                collection.Add(new DirectoryItem(new Item("Kosno", null)));
        }

        private void ContextAddPasswords_Click(object sender, RoutedEventArgs e)
        {
            if(sender is DirectoryItem)
            {
                ((DirectoryItem)ItemTree.SelectedItem).items.Add(new PasswordList((DirectoryItem)e.OriginalSource));
            }
            else
            {
                collection.Add(new PasswordList(null));
            }
        }

        private void ContextAddImage_Click(object sender, RoutedEventArgs e)
        {
            if (sender is DirectoryItem)
            {
                ((DirectoryItem)e.OriginalSource).items.Add(new ImageItem((DirectoryItem)e.OriginalSource, null));
            }
            else
                collection.Add(new ImageItem("New Image", null));
        }

        private void ItemTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            DebugBlock.Text = ItemTree.SelectedItem.ToString();
        }

        private void ContextMenu_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            Item arg = e.Source as Item;

            if(arg != null)
            {
                if (arg is DirectoryItem)
                {
                    DebugBlock.Text = "Directory";
                    DirectoryItem tmp = arg as DirectoryItem;
                    ContextFileName.IsEnabled = true;
                    ContextFileName.Header = tmp.itemName;
                    ContextSep1.IsEnabled = true;
                    ContextAddDirectory.IsEnabled = true;
                    ContextFile.IsEnabled = true;
                    ContextSep2.IsEnabled = true;
                    ContextRename.IsEnabled = true;
                    ContextDelete.IsEnabled = true;
                    return;
                }

                if (arg is ImageItem || arg is PasswordList)
                {
                    DebugBlock.Text = "NotDirectory";
                    ImageItem tmp = arg as ImageItem;
                    ContextFileName.IsEnabled = true;
                    ContextFileName.Header = tmp.itemName;
                    ContextSep1.IsEnabled = true;
                    ContextAddDirectory.IsEnabled = false;
                    ContextFile.IsEnabled = false;
                    ContextSep2.IsEnabled = false;
                    ContextRename.IsEnabled = true;
                    ContextDelete.IsEnabled = true;
                    return;
                }
            }

            DebugBlock.Text = "Background";
            ContextFileName.IsEnabled = false;
            ContextSep1.IsEnabled = false;
            ContextAddDirectory.IsEnabled = true;
            ContextFile.IsEnabled = true;
            ContextSep2.IsEnabled = false;
            ContextRename.Visibility = Visibility.Collapsed;
            ContextDelete.Visibility = Visibility.Collapsed;
        }
    }

    public class MyDTSelector : DataTemplateSelector
    {
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            FrameworkElement element = container as FrameworkElement;
            if(element != null && item is DirectoryItem)
            {
                return element.FindResource("DirectoryTemplate") as DataTemplate;
            }

            if (element != null)
            {
                return element.FindResource("NotDirectoryTemplate") as DataTemplate;
            }

            return null;
        }
    }
    public class MyContextMenuSelector : DataTemplateSelector
    {
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            FrameworkElement element = container as FrameworkElement;
            if (element != null && item is DirectoryItem)
            {
                return element.FindResource("DirectoryContextMenu") as DataTemplate;
            }

            return element.FindResource("NotDirectoryContextMenu") as DataTemplate;            
        }
    }

}

