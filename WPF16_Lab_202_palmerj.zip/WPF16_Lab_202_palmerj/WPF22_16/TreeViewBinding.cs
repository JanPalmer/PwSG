﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Controls;
using System.Windows;

namespace WPF22_16
{
    public class Item
    {
        public string itemName { get; set; }
        public Item parent { get; set; }

        public Item(string _itemName, Item _parent)
        {
            itemName = _itemName;
            parent = _parent;
        }
    }
    public class ImageItem : Item
    {
        public Uri image { get; set; }

        public ImageItem(Item _parent, Uri _image) : base("New Image", _parent)
        {
            image = _image;
        }
        public ImageItem(string _name, Item _parent) : base(_name, _parent)
        {
            image = null;
        }
    }
    public class PasswordItem : Item
    {
        public ImageItem icon;
        public string name;
        public string email;
        public string login;
        public string password;
        public string website;
        public string notes;
        public DateTime timeOfCreation;
        public DateTime lastEdited;
        public PasswordItem(string _itemName, Item _parent) : base(_itemName, _parent) { }
    }
    public class PasswordList : ImageItem
    {
        public List<PasswordItem> passwords { get; set; }
        public PasswordList(Item _parent) : base("New Passwords", _parent)
        {
            passwords = new List<PasswordItem>();
        }
    }
    public class DirectoryItem : Item
    {
        public List<Item> items { get; set; }
        public DirectoryItem(Item _parent) : base("New Directory", _parent)
        {
            items = new List<Item>();
        }
    }
}
