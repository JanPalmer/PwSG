﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;

namespace Wpf3DCube
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MyVideo_Loaded(object sender, RoutedEventArgs e)
        {
            MyVideo.Play();
        }

        private void MyVideo_MediaEnded(object sender, RoutedEventArgs e)
        {
            MyVideo.Position = TimeSpan.FromMilliseconds(1);
        }
        private void TextBox_Initialize(object sender, RoutedEventArgs e)
        {
            SpeedBox.Text = System.Convert.ToString(MyVideo.SpeedRatio);
        }

        private void TextBox_TextChanged(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key != System.Windows.Input.Key.Enter) return;

            //if (SpeedBox.Text == "") SpeedBox.Text = System.Convert.ToString(MyVideo.SpeedRatio);

            double tmp = System.Convert.ToDouble(SpeedBox.Text);
            if(tmp > 0 && tmp < 2)
            {
                MyVideo.SpeedRatio = tmp;
                SpeedBox.Text = System.Convert.ToString(MyVideo.SpeedRatio);
            }
            else
            {
                SpeedBox.Text = System.Convert.ToString(MyVideo.SpeedRatio);
            }
        }

        private void ButtonUp_Click(object sender, RoutedEventArgs e)
        {
            if(MyVideo.SpeedRatio + 0.1 <= 2)
            {
                MyVideo.SpeedRatio += 0.1;
                SpeedBox.Text = System.Convert.ToString(MyVideo.SpeedRatio);
            }
        }

        private void ButtonDown_Click(object sender, RoutedEventArgs e)
        {
            if (MyVideo.SpeedRatio - 0.1 > 0)
            {
                MyVideo.SpeedRatio -= 0.1;
                SpeedBox.Text = System.Convert.ToString(MyVideo.SpeedRatio);
            }
        }
    }
}
